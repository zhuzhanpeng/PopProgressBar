# 水滴落水波进度
## 效果如下:视频录制比较卡顿，实际很流畅
<img src="/preview/demo.gif">

## 使用方法

### 1，布局文件添加以下属性

#### app:circleColor 圆环颜色
#### app:progress 初始进度
#### app:waterColor 水滴和水波的颜色

### 2，setProgress() 方法设置当前的进度 
